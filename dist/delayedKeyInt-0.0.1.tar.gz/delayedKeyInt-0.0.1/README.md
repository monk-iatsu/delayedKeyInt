# delayedKeyInt
## a module to delay KeyboardInturrupt in python
### Installation:
`pip3 install delayedKeyInt`
### Usage:
`from delayedKeyInt import DelayedKeyboardInterrupt
with DelayedKeyboardInterrupt():
    do_stuff_then_raise()`

